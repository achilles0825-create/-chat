#!/bin/bash
cd "$(dirname "$0")"
python3 extract_assets.py
