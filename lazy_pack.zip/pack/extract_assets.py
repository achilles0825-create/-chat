import re, base64, os, sys

SRC = "index.html"
if not os.path.exists(SRC):
    print("找不到 index.html,請把你的 HTML 改名成 index.html 放在這個資料夾!")
    input("按 Enter 結束"); sys.exit(1)

html = open(SRC, encoding="utf-8").read()
os.makedirs("assets/fish", exist_ok=True)
os.makedirs("assets/weapons", exist_ok=True)
os.makedirs("assets/music", exist_ok=True)

def save(path, b64):
    with open(path, "wb") as f:
        f.write(base64.b64decode(b64))

fish_re = re.compile(
    r'(FISH_PIXEL_ART\.(\w+)\s*=\s*\{\s*flip:\s*(?:true|false),\s*src:\s*)"data:image/png;base64,([A-Za-z0-9+/=]+)"')
def fish_sub(m):
    p = f"assets/fish/{m.group(2)}.png"; save(p, m.group(3))
    return f'{m.group(1)}"{p}"'
html, n1 = fish_re.subn(fish_sub, html)

wp_re = re.compile(
    r'"(pistol|shotgun|machinegun|laser|rocket|railgun)":\s*"data:image/png;base64,([A-Za-z0-9+/=]+)"')
def wp_sub(m):
    p = f"assets/weapons/{m.group(1)}.png"; save(p, m.group(2))
    return f'"{m.group(1)}": "{p}"'
html, n2 = wp_re.subn(wp_sub, html)

os.replace(SRC, "index_backup_original.html")
open("index.html", "w", encoding="utf-8").write(html)
print(f"完成!魚圖 {n1} 張、武器圖 {n2} 張")
print("原檔已備份為 index_backup_original.html")
print("現在把整個資料夾(index.html + assets)上傳到 GitHub 即可")
input("按 Enter 結束")
